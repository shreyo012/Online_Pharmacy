﻿using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pharmacy_DAO;

namespace Online_Pharmacy_App_MVC.Controllers
{
    public class CustomersController : Controller
    {
        private readonly HttpClient _httpClient;
        public CustomersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5278/api/Customers");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var customer = JsonConvert.DeserializeObject<List<Customer>>(jsondata);
                return View(customer);
            }
            return View();
        }


        // GET: CustomersController/Details/5
        public ActionResult GetCustomerDetails(int id)
        {
            return View();
        }

        // GET: CustomersController/Create
        public ActionResult AddCustomerDetails()
        {
            return View();
        }

        // POST: CustomersController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCustomersDetails(Customer customer)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5278/api/Customers", customer);
            return RedirectToAction(nameof(Default));
        }

        // GET: CustomersController/Edit/5
        public ActionResult UpdateCustomerDetails(int id)
        {
            return View();
        }

        // POST: CustomersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddCustomerDetails(Customer customer)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5278/api/Customers", customer);
            return RedirectToAction(nameof(Default));
        }

        

        // GET: CustomersController/Delete/5
        public ActionResult DeleteCustomerDetails(int id)
        {
            return View();
        }

    
        public async Task<IActionResult> RemoveCustomerDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5278/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var customer = JsonConvert.DeserializeObject<Customer>(jsondata);
                return View(customer);
            }
            return NotFound();
        }

        [HttpPost, ActionName("RemoveCustomerDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5278/api/Customers/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
