﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pharmacy_DAO;

namespace Online_Pharmacy_App_MVC.Controllers
{
    public class LoginsController : Controller
    {
        private readonly HttpClient _httpClient;
        public LoginsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController   
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5278/api/Logins");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var login = JsonConvert.DeserializeObject<List<Login>>(jsondata);
                return View(login);
            }
            return View();
        }



        // GET: LoginsController/Details/5
        public ActionResult GetLoginDetails(int id)
        {
            return View();
        }

        // GET: LoginsController/Create
        public ActionResult AddLoginDetails()
        {
            return View();
        }

        // POST: LoginsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddLoginDetails(Login login)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5278/api/Logins", login);
            return RedirectToAction(nameof(Default));
        }

        // GET: LoginsController/Edit/5
        public ActionResult UpdateLoginDetails(int id)
        {
            return View();
        }

        // POST: LoginsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateLoginDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: LoginsController/Delete/5
        public ActionResult DeleteLoginDetails(int id)
        {
            return View();
        }
        public async Task<IActionResult> RemoveLoginDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5278/api/Logins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var login = JsonConvert.DeserializeObject<Login>(jsondata);
                return View(login);
            }
            return NotFound();
        }

        [HttpPost, ActionName("RemoveLoginDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5278/api/Logins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
