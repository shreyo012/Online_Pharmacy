﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pharmacy_DAO;
using System.Text;

namespace Online_Pharmacy_App_MVC.Controllers
{
    public class OrdersController : Controller
    {
        private readonly HttpClient _httpClient;
        public OrdersController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5278/api/Orders");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<List<Order>>(jsondata);
                return View(order);
            }
            return View();
        }

        // GET: OrdersController/Details/5
        public ActionResult GetOrder(int id)
        {
            return View();
        }

        // GET: OrdersController/Create
        public ActionResult AddOrder()
        {
            return View();
        }

        // POST: OrdersController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddOrder(Order order)
        {
            if (ModelState.IsValid)
            {
                var jsondata = JsonConvert.SerializeObject(order);
                var content = new StringContent(jsondata, Encoding.UTF8, "application/json");
                var response = await _httpClient.PostAsync("http://localhost:5278/api/Orders", content);
                if (response.IsSuccessStatusCode)
                {
                    return RedirectToAction(nameof(Default));
                }
            }
            return View(order);            
        }

        // GET: OrdersController/Edit/5
        public ActionResult UpdateOrder(int id)
        {
            return View();
        }

        // POST: OrdersController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateOrder(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: OrdersController/Delete/5
        public ActionResult DeleteOrder(int id)
        {
            return View();
        }
        public async Task<IActionResult> RemoveOrder(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5278/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var order = JsonConvert.DeserializeObject<Order>(jsondata);
                return View(order);
            }
            return NotFound();
        }

        [HttpPost, ActionName("RemoveOrder")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5278/api/Orders/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
