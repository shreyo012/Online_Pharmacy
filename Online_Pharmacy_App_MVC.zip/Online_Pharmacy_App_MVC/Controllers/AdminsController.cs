﻿using Microsoft.AspNetCore.Http;
using Microsoft.AspNetCore.Mvc;
using Newtonsoft.Json;
using Pharmacy_DAO;

namespace Online_Pharmacy_App_MVC.Controllers
{
    public class AdminsController : Controller
    {
        private readonly HttpClient _httpClient;
        public AdminsController(HttpClient httpClient)
        {
            _httpClient = httpClient;
        }
        // GET: AdminsController
        public async Task<IActionResult> Default()
        {
            var response = await _httpClient.GetAsync("http://localhost:5278/api/Admins");
        if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<List<Admin>>(jsondata);
                return View(admin);
            }
            return View();
        }

        // GET: AdminsController/Details/5
        public ActionResult GetAdminDetails(int id)
        {
            return View();
        }

        // GET: AdminsController/Create
        public ActionResult AddAdminDetails()
        {
            return View();
        }

        // POST: AdminsController/Create
        [HttpPost]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> AddAdminDetails(Admin admin)
        {
            var response = await _httpClient.PostAsJsonAsync("http://localhost:5278/api/Admins", admin);
            return RedirectToAction(nameof(Default));
        }

        // GET: AdminsController/Edit/5
        public ActionResult UpdateAdminDetails(int id)
        {
            return View();
        }

        // POST: AdminsController/Edit/5
        [HttpPost]
        [ValidateAntiForgeryToken]
        public ActionResult UpdateAdminDetails(int id, IFormCollection collection)
        {
            try
            {
                return RedirectToAction(nameof(Index));
            }
            catch
            {
                return View();
            }
        }

        // GET: AdminsController/Delete/5
        public ActionResult DeleteAdminDetails(int id)
        {
            return View();
        }

       
        public async Task<IActionResult> RemoveAdminDetails(int id)
        {
            var response = await _httpClient.GetAsync($"http://localhost:5278/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                var jsondata = await response.Content.ReadAsStringAsync();
                var admin = JsonConvert.DeserializeObject<Admin>(jsondata);
                return View(admin);
            }
            return NotFound();
        }

        [HttpPost, ActionName("RemoveAdminDetails")]
        [ValidateAntiForgeryToken]
        public async Task<IActionResult> RemoveConfirmed(int id)
        {
            var response = await _httpClient.DeleteAsync($"http://localhost:5278/api/Admins/{id}");
            if (response.IsSuccessStatusCode)
            {
                return RedirectToAction(nameof(Default));
            }
            return View();

        }
    }
}
