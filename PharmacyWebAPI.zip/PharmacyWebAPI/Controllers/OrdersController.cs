﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class OrdersController : ControllerBase
    {
        private readonly PharmacyDbContext _context;

        public OrdersController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Order> Get()
        {
            return _context.Orders.ToList();
        }


        [HttpGet("{id}")]
        public Order GetOrder(int id)
        {
            var order = _context.Orders.Find(id);

            if (order == null)
            {
                return new Order();
            }

            return order;
        }


        [HttpPost]
        public void PostMedicine([FromBody] Order order)
        {
            _context.Orders.Add(order);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutMedicine(int id, [FromBody] Order order)
        {
            _context.Entry(order).State = EntityState.Modified;
            _context.SaveChanges();
        }



        [HttpDelete("{id}")]
        public bool DeleteOrder(int id)
        {
            var order = _context.Orders.Find(id);
            if (order == null)
            {
                return false;
            }

            _context.Orders.Remove(order);
            _context.SaveChanges();
            return true;

        }
    }
}
