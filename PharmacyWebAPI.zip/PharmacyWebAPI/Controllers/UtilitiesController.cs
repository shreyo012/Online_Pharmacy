﻿using Microsoft.AspNetCore.Mvc;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class UtilitiesController : ControllerBase
    {
        private readonly PharmacyDbContext _context;

        public UtilitiesController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet("{customer_id}")]
        public IEnumerable<Order> GetPreviousOrders(int customer_id)
        {
            return _context.Orders.Where(m => m.CustomerId == customer_id).ToList();
        }

        // GET api/<UtilitiesController>/5
        [HttpGet("{id}")]
        public string Get(int id)
        {
            return "value";
        }

        // POST api/<UtilitiesController>
        [HttpPost]
        public void Post([FromBody] string value)
        {
        }

        // PUT api/<UtilitiesController>/5
        [HttpPut("{id}")]
        public void Put(int id, [FromBody] string value)
        {
        }

        // DELETE api/<UtilitiesController>/5
        [HttpDelete("{id}")]
        public void Delete(int id)
        {
        }
    }
}
