﻿using Microsoft.AspNetCore.Mvc;
using Microsoft.EntityFrameworkCore;
using Pharmacy_DAO;

// For more information on enabling Web API for empty projects, visit https://go.microsoft.com/fwlink/?LinkID=397860

namespace PharmacyWebAPI.Controllers
{
    [Route("api/[controller]")]
    [ApiController]
    public class MedicinesController : ControllerBase
    {
        private readonly PharmacyDbContext _context;

        public MedicinesController(PharmacyDbContext context)
        {
            _context = context;
        }

        [HttpGet]
        public IEnumerable<Medicine> Get()
        {
            return _context.Medicines.ToList();
        }


        [HttpGet("{id}")]
        public Medicine GetMedicine(int id)
        {
            var medicine = _context.Medicines.Find(id);

            if (medicine == null)
            {
                return new Medicine();
            }

            return medicine;
        }


        [HttpPost]
        public void PostMedicine([FromBody] Medicine medicine)
        {
            _context.Medicines.Add(medicine);
            _context.SaveChanges();
        }


        [HttpPut("{id}")]
        public void PutMedicine(int id, [FromBody] Medicine medicine)
        {
            _context.Entry(medicine).State = EntityState.Modified;
            _context.SaveChanges();
        }



        [HttpDelete("{id}")]
        public bool DeleteMedicine(int id)
        {
            var medicine = _context.Medicines.Find(id);
            if (medicine == null)
            {
                return false;
            }

            _context.Medicines.Remove(medicine);
            _context.SaveChanges();
            return true;

        }
    }
}

